export CLASSPATH=$CLASSPATH:./results/bin/jsunit.jar:./results/lib/org.mortbay.jetty-jdk1.2.jar:./results/lib/jdom.jar:./results/lib/javax.servlet.jar:./results/lib/junit.jar:./results/lib/xerces.jar:./results/lib/junit.jar
java junit.swingui.TestRunner -noloading net.jsunit.StandaloneTest
